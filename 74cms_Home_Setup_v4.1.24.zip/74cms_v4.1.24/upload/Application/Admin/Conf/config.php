<?php 
return array(
	'URL_MODEL' => 0,
	'SHOW_PAGE_TRACE'		=> false,
	'DEFAULT_THEME' 		=> 'default',
);
?>