<?php
	return array(
		'audit_reason_null_error_jobs_id' => '职位id不能为空!',
		'audit_reason_null_error_company_id' => '企业id不能为空!',
		'audit_reason_null_error_resume_id' => '简历id不能为空!',
		
		'audit_reason_enum_error_jobs_id' => '职位id错误!',
		'audit_reason_enum_error_company_id' => '企业id企业错误！',
		'audit_reason_enum_error_resume_id' => '简历id错误！',
	);
?>