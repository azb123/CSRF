<?php 
return array(
		/*
		**为空提示
		*/
		'crons_null_error_name'=> '任务名称不能为空！', 
		'crons_null_error_filename'=> '任务脚本不能为空！', 
		/*
			长度提示
		*/
		'crons_length_error_name' => '任务应在1~15个字内！',
		'crons_length_error_filename' => '任务脚本应在1~15个字内！',
)		
?>