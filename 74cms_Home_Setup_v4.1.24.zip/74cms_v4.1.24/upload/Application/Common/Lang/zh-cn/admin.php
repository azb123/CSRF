<?php
	return array(
		'admin_null_error_admin_name' => '请输入用户名！',
		'admin_null_error_email' => '请输入邮箱！',
		'admin_null_error_pwd' => '请输入密码！',
		'admin_null_error_rpwd' => '请确认密码！',
		'admin_null_error_rank' => '请输入头衔！',
		
		'admin_format_error_email' => '请输入正确格式的邮箱！',
		'admin_equal_error_rpwd' => '两次输入密码不一致！',
	);
?>