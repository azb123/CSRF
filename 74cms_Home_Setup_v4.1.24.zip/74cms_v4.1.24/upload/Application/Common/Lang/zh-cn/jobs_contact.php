<?php 
return array(
		'jobs_contact_null_error_pid' => '职位id不能为空！',
		'jobs_contact_enum_error_pid' => '请填写正确的职位id！',
		/*
		**规则提示
		*/
		'pid_format_error' => '请填写正确的职位id！',
		'telephone_format_error' => '请填写正确的手机！',
		'landline_tel_format_error' => '请填写正确的固定电话！',
		'email_format_error' => '请填写正确的邮箱！',
)
?>