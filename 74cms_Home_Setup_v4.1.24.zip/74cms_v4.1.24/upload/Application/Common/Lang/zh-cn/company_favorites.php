<?php 
return array(
		/*
		**为空提示
		*/
		'company_favorites_null_error_resume_id' => '简历id不能为空！', 
		'company_favorites_null_error_company_uid' => '公司uid不能为空！', 
		/*
		**数字提示
		*/
		'company_favorites_enum_error_resume_id' => '请填写正确的简历id！', 
		'company_favorites_enum_error_company_uid' => '请填写正确的公司uid！', 
)
?>