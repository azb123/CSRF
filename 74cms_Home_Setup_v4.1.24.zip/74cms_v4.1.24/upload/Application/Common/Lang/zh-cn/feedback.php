<?php 
return array(
		/*
		**为空提示
		*/
		'feedback_null_error_infotype'=> '请选择反馈类型！', 
		'feedback_null_error_feedback'=> '反馈内容不能为空！', 
		'feedback_null_error_tel'=> '联系方式不能为空！', 
		'feedback_tel'=> '请输入正确QQ、电话、邮箱！', 
)		
?>