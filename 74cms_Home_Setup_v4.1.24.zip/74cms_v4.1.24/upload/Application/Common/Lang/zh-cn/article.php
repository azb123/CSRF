<?php
	return array(
		'article_null_error_title' => '新闻标题不能为空！',
		'article_null_error_parentid' => '请选择新闻分类！',

		'article_enum_error_type_id' => '请正确选择新闻类型！',
		'article_enum_error_parentid' => '请正确选择新闻类型！',
		'article_length_error_title' => '新闻标题应在1~50个字内！',
	);
?>