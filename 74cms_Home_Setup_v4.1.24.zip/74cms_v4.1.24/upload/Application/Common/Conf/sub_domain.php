<?php 
return array (
  'APP_SUB_DOMAIN_RULES' => array (),
);