<?php
return array (
	'PWDHASH'=> ''
);